"""Compare XE v2 population settings against the frozen pilot, without retuning on outcomes."""
import argparse
import hashlib
import itertools
import json
import random
import statistics
import subprocess
import time
from collections import defaultdict
from pathlib import Path

from run import ROOT, annotate, apex_problem, save, source_manifest
from instances import prepare


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=ROOT/"results/xe-change/comparison")
    parser.add_argument("--seeds", default="19,42,73")
    parser.add_argument("--instances", default="")
    args = parser.parse_args()
    out = args.out.resolve()
    instances = prepare()
    if args.instances:
        wanted = set(args.instances.split(","))
        instances = [i for i in instances if i["id"] in wanted]
        assert {i["id"] for i in instances} == wanted
    seeds = list(map(int,args.seeds.split(",")))
    variants = {"XE16":16, "XE64":64}
    binary = ROOT/"target/release/apex-benchmark.exe"
    baseline = ROOT/"results/pilot"
    historical = json.loads((baseline/"results.json").read_text(encoding="utf-8"))
    manifest = dict(evaluations=1000, seeds=seeds, instances=[i["id"] for i in instances],
        variants=variants, source_hashes=source_manifest(), binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
        baseline_binary_sha256=historical["manifest"]["binary_sha256"],
        baseline_results_sha256=hashlib.sha256((baseline/"results.json").read_bytes()).hexdigest(),
        protocol="Sequential single-worker fixed-evaluation pilot; same instances, objectives, seeds and decoder as before. XE v2 filters applicable operators, skips duplicate proposals, uses binary tournament and 50% crossover-kind probability. Only population size differs between new variants. Old XE and NSGA-II timings are historical, not contemporaneous controlled measurements. No claims of statistical significance or equal-time superiority.")
    save(out/"manifest.json",manifest)
    jobs = list(itertools.product(instances,variants,seeds))
    random.Random(20260925).shuffle(jobs)
    rows=[]
    start=time.perf_counter()
    for count,(ins,method,seed) in enumerate(jobs,1):
        row=dict(instance=ins["id"],kind=ins["kind"],method=method,seed=seed,nominal_evaluations=1000)
        try:
            request=dict(problem=apex_problem(ins),kind=ins["kind"],method="G",evaluations=1000,seed=seed,
                         evolution=dict(population_size=variants[method],crossover_share=.5,parent_selection="tournament"))
            begin=time.perf_counter()
            r=subprocess.run([str(binary)],input=json.dumps(request),capture_output=True,text=True,timeout=240)
            assert r.returncode==0, r.stdout+r.stderr
            row.update(json.loads(r.stdout))
            row["method"]=method
            row["cold_process_seconds"]=time.perf_counter()-begin
            annotate(ins,row,1000)
            assert row["evaluations"]==row["observed_attempts"]==len(row["trace"])
            names=["tardy_insert","route","conditional_mode","conditional_reset"]
            if ins["kind"]!="FJSP": names.append("main_mode")
            for operator in row["phases"][0]["operators"]:
                if operator["id"].split(":")[1].split("@")[0] in names:
                    assert operator["attempts"]==operator["skipped"]==0
                assert operator["unchanged"]==0
        except Exception as error:
            row.update(valid=False,error=f"{type(error).__name__}: {error}")
        save(out/"runs"/f"{ins['id']}-{method}-{seed}.json",row)
        rows.append(row)
        print(json.dumps(dict(done=count,total=len(jobs),instance=ins["id"],method=method,valid=row["valid"],error=row.get("error"),seconds=row.get("seconds"),elapsed=time.perf_counter()-start)),flush=True)
    assert source_manifest()==manifest["source_hashes"], "Source changed during experiment"
    ids={i["id"] for i in instances}
    old=[dict(r,method="XE-legacy" if r["method"]=="G" else r["method"]) for r in historical["runs"]
         if r["instance"] in ids and r["seed"] in seeds and r["method"] in ["G","NSGA-II"]]
    ref={i:dict(v) for i,v in historical["instance_reference"].items() if i in ids}
    for r in rows:
        if r.get("valid"):
            x=ref[r["instance"]]
            x["hv"]=max(x["hv"],r["hypervolume"])
            x["ms"]=min(x["ms"],r["best_ms"])
            x["ft"]=min(x["ft"],r["best_ft"])
    groups=defaultdict(list)
    for r in old+rows:
        if r.get("valid"): groups[r["kind"],r["method"]].append(r)
    aggregates=[]
    for (kind,method),rr in sorted(groups.items()):
        ops=[op for r in rr for ph in r.get("phases",[]) for op in ph["operators"]]
        aggregates.append(dict(kind=kind,method=method,runs=len(rr),
            hv_deficit_percent=statistics.mean(100*(1-r["hypervolume"]/ref[r["instance"]]["hv"]) for r in rr),
            ms_gap_percent=statistics.mean(100*(r["best_ms"]/ref[r["instance"]]["ms"]-1) for r in rr),
            ft_gap_percent=statistics.mean(100*(r["best_ft"]/ref[r["instance"]]["ft"]-1) for r in rr),
            median_seconds=statistics.median(r["seconds"] for r in rr),
            evaluations=sum(r["evaluations"] for r in rr),
            skipped=sum(op.get("skipped",0) for op in ops) if ops else None,
            unchanged_evaluated=sum(op["unchanged"] for op in ops) if ops else None))
    compact=[{k:v for k,v in r.items() if k not in ["archive","trace","options","phases"]} for r in rows]
    save(out/"results.json",dict(manifest=manifest,completed=len(rows),valid=sum(r.get("valid",False) for r in rows),instance_reference=ref,aggregates=aggregates,runs=compact))
    lines=["# XE applicability and parameter comparison", "", manifest["protocol"], "",
        "References use the best observed values across the original full pilot and these new runs; they are not optima. MS and FT extrema can belong to different schedules. Smaller gaps are better. XE-legacy and NSGA-II rows retain original pilot timings.", "",
        "| Class | Method | Runs | HV deficit % | MS gap % | FT gap % | Median seconds | Skipped proposals |",
        "|---|---|---:|---:|---:|---:|---:|---:|"]
    for r in aggregates:
        lines.append(f"| {r['kind']} | {r['method']} | {r['runs']} | {r['hv_deficit_percent']:.3f} | {r['ms_gap_percent']:.2f} | {r['ft_gap_percent']:.2f} | {r['median_seconds']:.3f} | {r['skipped'] if r['skipped'] is not None else '-'} |")
    lines += ["", "Both XE16 and XE64 use operator v2, tournament parents and a 0.5 crossover-kind proposal probability. XE16 inherits the previous population size; XE64 uses its independent override. Inapplicable baseline operators were asserted to have zero attempts and zero skips. Skipped duplicate proposals were separately recorded; they consume runtime but not candidate evaluations. All exported nondominated schedules received the independent audit."]
    (out/"report.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(dict(completed=len(rows),valid=sum(r.get("valid",False) for r in rows),report=str(out/"report.md"))),flush=True)


if __name__=="__main__":
    main()
