# Standalone MS / FT pilot benchmark

## Expanded size-coverage rerun

The new `scaling.py` runner preserves the pilot and reruns every selected case
against a freshly built, frozen copy of the current implementation. The design
is fixed in [`scaling-protocol.json`](scaling-protocol.json) before execution.
It retains all 15 legacy cases, includes all 15 distributed Brandimarte cases,
and selects two identifiers by a fixed SHA-256 ranking from each Taillard JSP
and PFSP size block and each Behnke–Geiger FJSP job/machine block. The full
280-candidate inclusion ledger is exported, including excluded cases.

The resulting matrix has 88 instances (21 JSP, 39 FJSP, 28 PFSP), 12 methods,
three seeds and 1,000 evaluations per search: 3,168 runs. F uses one construction.
Maximum operation counts are 2,000 (JSP), 500 (FJSP) and 10,000 (PFSP).
These counts describe different problem structures, not equal difficulty.

At the user's request, eight independent local runs execute concurrently;
each algorithm uses one worker. A common 240-second process watchdog applies
to every method. Runtime includes host contention and cannot establish isolated
speedups. Timeouts/errors remain in the matrix, and paired quality summaries
require all methods and all seeds on an instance. Old results are never reused.
This is an expanded stress test after earlier development, not independent
confirmation or an externally preregistered study.

```powershell
& benchmark/.venv/Scripts/python.exe benchmark/scaling.py --out benchmark/results/scaling-20260924-current-parallel
& benchmark/.venv/Scripts/python.exe benchmark/results/scaling-20260924-current-parallel/snapshot/benchmark/scaling.py --execute benchmark/results/scaling-20260924-current-parallel
```

For an unattended run, launch the second command as a hidden local process with
stdout/stderr redirected to files. The frozen runner writes `status.json`, all
`runs/*.json`, `results.json`, `report.md`, and a final `integrity-check.json`.
The final validator rechecks input hashes, the prescribed matrix and exported
schedules. A passing integrity check can contain documented solver failures.
No LLM calls, subscriptions, Codex automations or agent polling are needed.
The host must remain powered on and awake. Do not launch two coordinators for
the same output directory; `execution.lock` prevents this.

Behnke–Geiger citation: *Test Instances for the Flexible Job Shop Scheduling
Problem with Work Centers*, Research Report RR-12-01-01, January 2012,
[archived report](https://d-nb.info/1023241773/34). Source distributions and
raw hashes remain in the frozen manifest. The original acquisition format and
algorithm settings below continue to apply.

This directory contains four standard pymoo algorithms, discrete scheduling adapters, a separate executable for eight APEX configurations, public instance acquisition, independent schedule validation, and a JSON experiment runner. The application source is not modified. The native executable compiles the existing Rust modules by reference so their internal observation callbacks can be used without editing or copying the algorithms. Its additional PFSP hard-rule adapter and experiment orchestration live only here.

The problem classes are classical static JSP, FJSP and **permutation** FSP. Objectives are makespan and total **job** flowtime. All jobs are released at zero; no due dates or extra constraints are synthesized. Downloaded input and generated results are ignored by version control.

## Reproduce on Windows

The original `results/pilot` is historical evidence for operator version 1. The current source contains the XE applicability/deduplication update (operator version 2); rebuilding it is a new experiment, not a reproduction of those old numbers. The original pilot executable is preserved locally at `results/xe-change/baseline/apex-benchmark.exe`, alongside its native-wrapper and evolution-source snapshots. Manifest hashes identify both versions.

```powershell
py -3.11 -m venv benchmark/.venv
& benchmark/.venv/Scripts/python.exe -m pip install -r benchmark/requirements-lock.txt
& "$env:USERPROFILE/.cargo/bin/cargo.exe" build --release --locked --manifest-path benchmark/Cargo.toml
& benchmark/.venv/Scripts/python.exe -m pytest benchmark -q
& benchmark/.venv/Scripts/python.exe benchmark/run.py --evaluations 1000 --seeds 19,42,73
& benchmark/.venv/Scripts/python.exe benchmark/analyze.py
```

Use `--out`, `--instances ft06,mk01,ta001`, or `--methods NSGA-II,SPEA2,MOEA-D,SMS-EMOA` to select a different run. Evaluation budgets must be multiples of 100 and at least 100, so the default population batches have compatible stopping boundaries. `--resume` checks settings, binary and source hashes before reusing completed files. Use a new output directory when changing a configuration. A failure is recorded in JSON and is not silently omitted.

## Inputs

| Class | Instances | Jobs / machines |
| --- | --- | --- |
| JSP | ft06, la01, la06, la16, abz5 | 6/6, 10/5, 15/5, 10/10, 10/10 |
| FJSP | Brandimarte mk01 through mk05 | 10/6, 10/6, 15/8, 15/8, 15/4 |
| PFSP | Taillard ta001 through ta005 | 20/5 each |

Sources are [OR-Library](https://people.brunel.ac.uk/~mastjjb/jeb/orlib/files/jobshop1.txt), the [SchedulingLab Brandimarte collection](https://github.com/SchedulingLab/fjsp-instances/tree/main/brandimarte), and [Taillard's original data](https://mistic.iict-heig-vd.ch/taillard/problemes.dir/ordonnancement.dir/flowshop.dir/tai20_5.txt). Each source file and parsed input has provenance in `data/instances.json`; source SHA-256 values are retained in the result manifest. SchedulingLab files use zero-based machine indices. Historical Taillard bounds are metadata, not assertions about current best known values. This small PFSP selection does not test size scaling.

## Implementations and fixed settings

External algorithms use **pymoo 0.6.2**: NSGA-II, SPEA2, MOEA/D and SMS-EMOA. Selection and survival are unchanged. Population defaults are 100; MOEA/D receives 100 evenly spaced two-objective reference directions and retains its other defaults. Resolved offspring counts, decomposition, duplicate handling and neighborhood size are saved per run. In this pymoo release SMS-EMOA's default offspring configuration is retained; this is a comparison with the library variant, not an assertion that every detail equals the original steady-state paper.

The four methods share random discrete initialization and the same problem-specific variation:

- JSP: repeated job-ID operation sequence; POX crossover and one swap mutation.
- FJSP: the same sequence plus machine choices indexed by operation identity; POX and uniform machine crossover; one sequence swap plus one random eligible-machine reassignment where possible.
- PFSP: job permutation; LOX crossover with linear fill, and one job swap.

The generic pymoo crossover/mutation constructor defaults, respectively **0.9 per mating** and **1.0 per offspring**, are explicitly fixed for these discrete operators. The mutation changes positions, not every gene independently. FJSP mutation performs both a sequence and a machine change. The uniform machine crossover selects either parent's gene with probability 0.5. These are documented adapter settings, not a claim of a universal scheduling default or reproduction of a complete published algorithm. No parameter search or local search was added. Operator precedents: [POX / uniform crossover](https://www.atlantis-press.com/journals/ijndc/125905632/view), [POX / swap / machine reassignment](https://www.researchgate.net/publication/375725643_Solving_Flexible_Shop_Scheduling_Problems_Based_on_Improved_NSGA-II), and [LOX / swap](https://www.researchgate.net/publication/221007159_An_improved_multiobjective_memetic_algorithm_for_permutation_flow_shop_scheduling).

External JSP/FJSP decoding inserts operations into the earliest feasible machine gap. PFSP uses the standard permutation completion recurrence. The APEX decoder remains unchanged and constructs schedules using its own placement rules. Consequently results compare complete implementations, including their different search spaces and decoder costs.

APEX configurations are **F**, **T**, **B**, **G**, **T-B**, **T-G**, **B-G**, **T-B-G**: FastPlanner, Trainer, Plus tree search, and the direct GA. Pairs split the total evaluation budget equally; the triple splits it into thirds. Unused evaluations carry forward. F performs one construction and returns; it is a low-cost reference and does not consume the full search allowance. Default internal APEX population size is 16, default tree parameters are retained, and Trainer/GA use Pareto selection. The tree and single incumbent use the equally weighted normalized objectives. GA retains default discounted-UCB operator selection. There is no tuning of the APEX parameters.

Hybrid handoff passes **one validated seed**. T-to-B transfers the best actually evaluated Q policy and its schedule; a potentially better classic-reference incumbent remains retained separately. The GA receives an unpinned genome from the best incumbent without freezing machine choices. Observer archives do not seed or influence the algorithms. These hybrids are explicit benchmark orchestrations, not the production multi-policy `improve` portfolio. Their settings and per-phase operator/node evidence are saved.

The benchmark-only PFSP policy derives job order from the first machine and filters later-machine candidates to preserve that order. It constrains construction order without adding artificial product-release dependencies between different jobs. Both the native validator and the Python audit check the common permutation. This native policy incurs overhead that is included in runtime.

## Measurements and files

- `results/pilot/manifest.json`: source and binary hashes, package versions, instance provenance, seeds, budgets and settings.
- `results/pilot/runs/*.json`: every run's complete objective/time trace, nondominated schedules, per-phase evidence, validation status and preferences.
- `results/pilot/results.json`: compact run records and per-class aggregates.
- `results/pilot/report.md`: human-readable aggregate table.

All algorithms use one worker. Quality and elapsed computation time are measured at a fixed candidate-evaluation allowance; they are separate columns. Failed proposals count, and duplicate schedules that are actually evaluated still count. Native prefix probes are extra work within the measured runtime, not additional complete schedule evaluations. Some native failed attempts can be rejected before decoding; counters are preserved. The pilot is not an equal-wall-time comparison or a time-to-target experiment.

Internal wall time includes setup, construction, search, observation and online validation; it excludes importing Python packages, parsing raw sources, serializing final outputs and post-run audit. Native cold process latency is an additional field. Python CPU time is recorded; native CPU time is explicitly unavailable. Both runtimes execute correctness checks, but their implementations and overhead differ. Timing comparisons are implementation measurements, not pure algorithmic complexity claims.

All nondominated **observed** solutions are retained independently of internal archive/population caps. Every external candidate is independently checked online; APEX internally validates its candidates, and all exported nondominated schedules from every method receive the separate Python audit. The audit checks exact operation coverage, eligibility, processing duration, job precedence, machine non-overlap, PFSP permutation, makespan and job flowtime. No infeasible schedule is accepted through a penalty score.

For S = sum over operations of their maximum eligible processing time and n jobs, all methods receive normalized objectives (MS/S, FT/(n*S)). The hypervolume reference is (1.1, 1.1). Preference weights 0.0 through 1.0 are applied **after** each biobjective run. Reported minimum MS and FT can come from different schedules. Aggregate gaps are relative to the best observed value on that instance anywhere in this pilot, not a known optimum; the hypervolume deficit is similarly relative to the best observed archive. Three seeds and five instances per class provide exploratory evidence only. Deterministic F repeats are timing repetitions, not independent quality samples.

## Verification

```powershell
& "$env:USERPROFILE/.cargo/bin/cargo.exe" fmt --manifest-path benchmark/Cargo.toml --check
& "$env:USERPROFILE/.cargo/bin/cargo.exe" clippy --manifest-path benchmark/Cargo.toml --all-targets -- -D warnings
& "$env:USERPROFILE/.cargo/bin/cargo.exe" test --manifest-path benchmark/Cargo.toml
& benchmark/.venv/Scripts/python.exe -m pytest benchmark -q
```

These checks cover benchmark logic and the referenced core's compilation/lints. The native binary has dedicated PFSP validation tests, while Python tests include hand-computed objectives, operation/machine corruption, nonpermutation schedules, genetic representation preservation and all eight native variants. The existing application's integration test suite is not duplicated into this separate package.

## XE follow-up

Run `benchmark/.venv/Scripts/python.exe benchmark/xe_compare.py` after building the benchmark release binary. The follow-up compares population 16 and 64 with applicability filtering, pre-evaluation duplicate checks, tournament parent selection and a 0.5 crossover-kind probability. It retains the original XE and NSGA-II pilot as historical references. Results and operator evidence are saved under `results/xe-change/comparison/`. The original and follow-up runtime columns were measured at different times; they are descriptive implementation measurements. All new candidates retain the existing decoder and hard-rule validator.
