"""Produce descriptive pilot tables and a standalone comparison figure."""
import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from run import METHODS, ROOT, save


def analyze(directory):
    report = json.loads((directory/"results.json").read_text(encoding="utf-8"))
    rows = [r for r in report["runs"] if r.get("valid")]
    group = defaultdict(list)
    for row in rows:
        group[row["method"]].append(row)
    global_table = []
    for method in METHODS:
        values = group[method]
        if not values:
            continue
        refs = report["instance_reference"]
        global_table.append(dict(method=method, runs=len(values),
            hv_deficit_percent=statistics.mean(100*(1-r["hypervolume"]/refs[r["instance"]]["hv"]) for r in values),
            ms_gap_percent=statistics.mean(100*(r["best_ms"]/refs[r["instance"]]["ms"]-1) for r in values),
            ft_gap_percent=statistics.mean(100*(r["best_ft"]/refs[r["instance"]]["ft"]-1) for r in values),
            median_seconds=statistics.median(r["seconds"] for r in values)))
    selected = {}
    for kind in ["JSP","FJSP","PFSP"]:
        candidates = [r for r in report["aggregates"] if r["kind"] == kind]
        selected[kind] = dict(
            best_hv=min(candidates,key=lambda r:r["mean_hv_deficit_percent"]),
            best_ms=min(candidates,key=lambda r:r["mean_ms_gap_percent"]),
            best_ft=min(candidates,key=lambda r:r["mean_ft_gap_percent"]),
            fastest_search=min((r for r in candidates if r["method"] != "F"),key=lambda r:r["median_seconds"]))
    analysis = dict(global_table=global_table, per_class=selected,
        note="Descriptive results; gaps use best observed reference; MS and FT extrema may belong to different schedules; F spends one evaluation.")
    save(directory/"analysis.json", analysis)
    plt.rcParams.update({"font.size":9, "axes.spines.top":False, "axes.spines.right":False})
    fig, axes = plt.subplots(2,3,figsize=(15,9),layout="constrained")
    colors = ["#d58b27" if method in METHODS[:8] else "#347eae" for method in METHODS]
    for column,kind in enumerate(["JSP","FJSP","PFSP"]):
        values = {r["method"]:r for r in report["aggregates"] if r["kind"]==kind}
        methods = [m for m in METHODS if m in values]
        for row, field, label in [(0,"mean_hv_deficit_percent","Mean HV deficit vs best observed (%)"),
                                   (1,"median_seconds","Median computation time (s, log scale)")]:
            ax=axes[row,column]
            ax.barh(methods,[values[m][field] for m in methods],color=[colors[METHODS.index(m)] for m in methods])
            ax.invert_yaxis()
            ax.set_title(kind)
            ax.set_xlabel(label)
            ax.grid(axis="x",alpha=.18)
            ax.set_axisbelow(True)
            if row:
                ax.set_xscale("log")
    budget=report["manifest"]["evaluation_budget"]
    fig.suptitle(f"MS / job-flowtime pilot: {budget:,} evaluations, 5 instances per class, 3 seeds\nAPEX configurations (orange), standard pymoo methods (blue); FastPlanner F uses one evaluation",fontsize=13)
    fig.savefig(directory/"comparison.png",dpi=150)
    plt.close(fig)
    lines=["", "## Overall descriptive comparison", "", "Every instance has equal weight. Smaller values are better. F uses one construction.", "",
        "| Method | HV deficit % | MS gap % | FT gap % | Median seconds |", "|---|---:|---:|---:|---:|"]
    for row in global_table:
        lines.append(f"| {row['method']} | {row['hv_deficit_percent']:.3f} | {row['ms_gap_percent']:.2f} | {row['ft_gap_percent']:.2f} | {row['median_seconds']:.3f} |")
    path=directory/"report.md"
    text=path.read_text(encoding="utf-8").split("\n## Overall descriptive comparison")[0]
    path.write_text(text+"\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(analysis,indent=2))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("directory",nargs="?",type=Path,default=ROOT/"results"/"pilot")
    analyze(parser.parse_args().directory.resolve())
